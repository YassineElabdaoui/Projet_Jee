package org.sid.coustumerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoustumerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoustumerServiceApplication.class, args);
	}

}
