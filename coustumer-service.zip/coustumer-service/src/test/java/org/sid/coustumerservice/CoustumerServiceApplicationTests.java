package org.sid.coustumerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoustumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
